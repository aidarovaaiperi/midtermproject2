package com.company;

import javax.swing.*;

public class Main extends JFrame {
    public Main(){
        setTitle("snake");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(300,345);
        setLocation(400,400);
        add(new GameField());
        setVisible(true);
    }
    public static void main(String[] args){
        Main mw = new Main();
    }

}
